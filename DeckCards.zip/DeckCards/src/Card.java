public class Card {
    String suite;
    String value;
    Card(String s,String v){
        suite=s;
        value=v;

    }

    public String getSuite() {
        return suite;
    }

    public void setSuite(String suite) {
        this.suite = suite;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

}
