import java.util.ArrayList;
import java.util.List;
import java.util.*;
public class Deck {
    // Cards
    List<Card> cards;
    int top, end;

    public Deck() {
        cards = new ArrayList<>();
        top = 0;
        end = 0;
    }
    Deck(List<Card> c){
        cards=c;
    }

    // shuffle()
    public void shuffle() {
        //fisher yates
        int ind;
        end = cards.size();
        Random rand = new Random();
        for (int i = end - 1; i > 0; i--) {
            ind = rand.nextInt(i + 1);

            Card temp = cards.get(ind);
            cards.add(ind, cards.get(i));
            cards.remove(i);
            cards.add(i, temp);
        }
    }

    // deal()
    public Card dealOneCard() {
        top = top + 1;
        System.out.println(cards.get(top-1).value);
        System.out.println(cards.get(top-1).suite);
        System.out.println(top);
        return cards.get(top - 1);
    }


}
