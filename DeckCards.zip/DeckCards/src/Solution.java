import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Solution {
    public static void main(String args[]){
        String[] suites = {"Clubs", "Hearts", "Spades", "Diamonds"};
        String[] numbers={"A","2","3","4","5","6","7","8","9","10","J","Q","K"};
        List<Card> cards=new ArrayList<>();
        for(int i=0;i<suites.length;i++){
            for(int j=0;j<numbers.length;j++){
                cards.add(new Card(suites[i],numbers[j]));
            }

        }
        System.out.println(cards.size());
        Deck d=new Deck(cards);
        d.shuffle();
        d.dealOneCard();
        d.dealOneCard();
        d.dealOneCard();
        d.dealOneCard();
        d.dealOneCard();
        d.dealOneCard();
        d.dealOneCard();
        d.dealOneCard();
        d.dealOneCard();


    }
}
